<?php

defined('BASEPATH') OR exit('Acção não permitida');

class Turmas extends CI_Controller {

    public function __construct() {
        parent::__construct();
         if(!$this->ion_auth->logged_in()){
            redirect('login');
        }
    }

    public function index() {

        $data = array(
            'titulo' => 'Listar turmas',
            'turmas' => $this->core_model->get_all('turma'),
            'professores' => $this->core_model->get_all('professor'),
        );
        $this->load->view('layout/header', $data);
        $this->load->view('turmas/index');
        $this->load->view('layout/footer');
    }

    public function edit($turma_id = NULL) {

        if (!$turma_id || !$this->core_model->get_by_id('turma', array('codTurma=' => $turma_id))) {
            $this->session->set_flashdata('error', 'Turma não encontrado');
            exit('turmas');
        } else {
            $this->form_validation->set_rules('nome', '', 'trim|required');
            $this->form_validation->set_rules('valorPropina', '', 'trim|required');
            $this->form_validation->set_rules('horario', '', 'trim|required|exact_length[5]');

            if ($this->form_validation->run()) {

                $data = elements(
                        array(
                    'nome',
                    'turma_activo',
                    'horario',
                    'diaSemana',
                    'codProfessor',
                    'professorAuxiliar',
                    'valorPropina',
                        ), $this->input->post()
                );



                $this->core_model->update('turma', $data, array('codTurma=' => $turma_id));

                redirect('turmas');
            } else {
                $data = array(
                    'titulo' => 'Editar Turma',
                    'turmas' => $this->core_model->get_by_id('turma', array('codTurma=' => $turma_id)),
                    'todasturmas' => $this->core_model->get_all('turma'),
                    'professores' => $this->core_model->get_all('professor'),
                    'todasturmasA' => $this->core_model->get_all('turma'),
                    'professoresA' => $this->core_model->get_all('professor'),
                );
                $this->load->view('layout/header', $data);
                $this->load->view('turmas/edit');
                $this->load->view('layout/footer');
            }
        }
    }

    public function del($turma_id = NULL) {
        if (!$turma_id || !$this->core_model->get_by_id('turma', array('codTurma=' => $turma_id))) {
            $this->session->set_flashdata('error', 'Turma não encontrado');
            redirect('turmas');
        }
        if (!$this->core_model->delete('turma', array('codTurma=' => $turma_id))) {
            $this->session->set_flashdata('sucess', 'Turma excluído com sucesso');
            redirect('turmas');
        } else {
            $this->session->set_flashdata('sucess', 'Erro ao excluír o turma');
            redirect('turmas');
        }
    }

    public function add() {
        $this->form_validation->set_rules('nome', '', 'trim|required|is_unique[turma.nome]');
        $this->form_validation->set_rules('turma_activo', '', 'required');
        $this->form_validation->set_rules('valorPropina', '', 'trim|required');
        if ($this->form_validation->run()) {
            $data = elements(
                    array(
                'nome',
                'turma_activo',
                'horario',
                'diaSemana',
                'codProfessor',
                'professorAuxiliar',
                'valorPropina',
                    ), $this->input->post()
            );

            $this->core_model->insert('turma', $data, $turma_id);
            redirect('turmas');
        } else {

            $data = array(
                'titulo' => 'Cadastrar Turmas',
                'todasturmas' => $this->core_model->get_all('turma'),
                'professores' => $this->core_model->get_all('professor'),
            );


            $this->load->view('layout/header', $data);
            $this->load->view('turmas/add');
            $this->load->view('layout/footer');
        }
    }

}
