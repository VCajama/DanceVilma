<?php

defined('BASEPATH') OR exit('Acção não permitida');

class Alunos extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if(!$this->ion_auth->logged_in()){
            redirect('login');
        }
        
    }

    public function index() {

        $data = array(
            'titulo' => 'Listar alunos',
            'alunos' => $this->core_model->get_all('aluno'),
            'mensalidades' => $this->core_model->get_all('mensalidade'),
        );


        $this->load->view('layout/header', $data);
        $this->load->view('alunos/index');
        $this->load->view('layout/footer');
    }

    public function edit($aluno_id = NULL) {
        //     !$aluno_id ||!$this->ion_auth->user($aluno_id)->row()
        if (!$aluno_id || !$this->core_model->get_by_id('aluno', array('codAluno=' => $aluno_id))) {
            $this->session->set_flashdata('error', 'Usuário não encontrado');
            exit('alunos');
        } else {
            $this->form_validation->set_rules('nome', '', 'trim|required');
            $this->form_validation->set_rules('dataNascimento', '', 'required');
            $this->form_validation->set_rules('endereco', '', 'trim|required');
            $this->form_validation->set_rules('sexo', '', 'required');
            $this->form_validation->set_rules('telefone', '', 'required|min_length[13]|max_length[15]');
            $this->form_validation->set_rules('telefoneAlternativo', '', 'required|min_length[13]|max_length[15]');
            $this->form_validation->set_rules('aluno_activo', '', 'required');
            if ($this->form_validation->run()) {
                $data = elements(
                        array(
                    'nome',
                    'dataNascimento',
                    'endereco',
                    'sexo',
                    'telefone',
                    'telefoneAlternativo',
                    'aluno_activo',
                        ), $this->input->post()
                );

                $this->core_model->update('aluno', $data, array('codAluno=' => $aluno_id));

                redirect('alunos');
            } else {
                $data = array(
                    'titulo' => 'Editar Aluno',
                    'alunos' => $this->core_model->get_by_id('aluno', array('codAluno=' => $aluno_id)),
                );
                $this->load->view('layout/header', $data);
                $this->load->view('alunos/edit');
                $this->load->view('layout/footer');
            }
        }
    }

    public function addMensalidade($aluno_id = NULL) {

        //     !$aluno_id ||!$this->ion_auth->user($aluno_id)->row()
        if (!$aluno_id || !$this->core_model->get_by_id('aluno', array('codAluno=' => $aluno_id))) {
            $this->session->set_flashdata('error', 'Usuário não encontrado');
            exit('alunos');
        } else {

            $this->form_validation->set_rules('nome', '', 'trim|required');
            $this->form_validation->set_rules('estado', '', 'required');

            if ($this->form_validation->run()) {
                //exit('alunos');
                $data = elements(
                        array(
                    'codAluno',
                    'estado',
                    'valorPropina',
                    'mes'
                        ), $this->input->post()
                );

                $this->core_model->insert('mensalidade', $data);
                $data2 = elements(
                        array(
                    'totalPagamento',
                        ), $this->input->post()
                );
                
                $this->core_model->update('aluno', $data2, array('codAluno=' => $aluno_id));
                redirect('mensalidades');
            } else {
                $data = array(
                    'titulo' => 'Editar Aluno',
                    'alunos' => $this->core_model->get_by_id('aluno', array('codAluno=' => $aluno_id)),
                    'meses' => $this->core_model->get_all('mes'),
                    'mensalidades' => $this->core_model->get_all('mensalidade')
                );
                $this->load->view('layout/header', $data);
                $this->load->view('alunos/addMensalidade');
                $this->load->view('layout/footer');
            }
        }
    }

    public function del($aluno_id = NULL) {
        if (!$aluno_id || !$this->core_model->get_by_id('aluno', array('codAluno=' => $aluno_id))) {
            $this->session->set_flashdata('error', 'Aluno não encontrado');
            redirect('alunos');
        }
        if (!$this->core_model->delete('aluno', array('codAluno=' => $aluno_id))) {
            $this->session->set_flashdata('sucess', 'Aluno excluído com sucesso');
            redirect('alunos');
        } else {
            $this->session->set_flashdata('sucess', 'Erro ao excluír o usuário');
            redirect('alunos');
        }
    }

    public function add() {
        $this->form_validation->set_rules('nome', '', 'trim|required');
        $this->form_validation->set_rules('dataNascimento', '', 'required');
        $this->form_validation->set_rules('endereco', '', 'trim|required');
        $this->form_validation->set_rules('sexo', '', 'required');
        $this->form_validation->set_rules('telefone', '', 'required|min_length[13]|max_length[15]');
        $this->form_validation->set_rules('telefoneAlternativo', '', 'required|min_length[13]|max_length[15]');
        $this->form_validation->set_rules('aluno_activo', '', 'required');



        if ($this->form_validation->run()) {
            $data = elements(
                    array(
                'nome',
                'dataNascimento',
                'endereco',
                'sexo',
                'telefone',
                'telefoneAlternativo',
                'aluno_activo',
                    ), $this->input->post()
            );

            $this->core_model->insert('aluno', $data, $aluno_id);
            redirect('alunos');
        } else {

            $data = array(
                'titulo' => 'Cadastrar Alunos',
            );


            $this->load->view('layout/header', $data);
            $this->load->view('alunos/add');
            $this->load->view('layout/footer');
        }
    }

}
