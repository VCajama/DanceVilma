<?php

defined('BASEPATH') OR exit('Acção não permitida');

class Usuarios extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (!$this->ion_auth->logged_in()) {
            redirect('login');
        }
    }

    public function index() {
        $data = array(
            'usuarios' => $this->ion_auth->users()->result(),
        );

        if (!$this->ion_auth->is_admin()) {
            redirect('/');
        }
        $this->load->view('layout/header', $data);
        $this->load->view('usuarios/index');
        $this->load->view('layout/footer');
    }

    public function add() {

        if (!$this->ion_auth->is_admin()) {
            redirect('/');
        }



        $this->form_validation->set_rules('username', '', 'trim|required|is_unique[users.username]');
        $this->form_validation->set_rules('first_name', '', 'trim|required');
        $this->form_validation->set_rules('email', '', 'trim|required|valid_email|is_unique[users.email]');
        $this->form_validation->set_rules('password', 'Senha', 'required|min_length[5]|max_length[255]');
        $this->form_validation->set_rules('confirm_password', 'Confirmar Senha', 'matches[password]');




        if ($this->form_validation->run()) {

            $email = $this->security->xss_clean($this->input->post('email'));
            $password = $this->security->xss_clean($this->input->post('password'));
            $username = $this->security->xss_clean($this->input->post('username'));


            $additional_data = array(
                'first_name' => $this->input->post('first_name'),
                'username' => $this->input->post('username'),
                'active' => $this->input->post('active'),
            );
            $group = array($this->input->post('perfil_usuario'));

            $additional_data = $this->security->xss_clean($additional_data);

            $group = $this->security->xss_clean($group);

            if ($this->ion_auth->register($username, $password, $email, $additional_data, $group)) {
                //                         $identity, $password, $email, $additional_data = [], $groups = [])
                $this->session->set_flashdata('sucess', 'Dados salvos com sucesso');
            } else {
                $this->session->set_flashdata('error', 'Erro ao salvar os dados');
            }


            redirect('usuarios');
        } else {

            $data = array(
                'titulo' => 'Cadastrar Usuário',
            );


            $this->load->view('layout/header', $data);
            $this->load->view('usuarios/add');
            $this->load->view('layout/footer');
        }
    }

    public function edit($user_id = NULL) {

        if (!$this->ion_auth->is_admin()) {
            $user_session = $this->session->userdata('user_id');
            if ($user_session != $user_id) {
                redirect('/');
            }
        }

        if (!$user_id || !$this->ion_auth->user($user_id)->row()) {
            $this->session->set_flashdata('error', 'Usuário não encontrado');
            redirect('usuarios');
        } else {

            $this->form_validation->set_rules('first_name', '', 'trim|required');
            $this->form_validation->set_rules('email', '', 'trim|required|valid_email'); //|callback_email_check
            $this->form_validation->set_rules('email', '', 'trim|required');
            $this->form_validation->set_rules('password', 'Senha', 'min_length[5]|max_length[255]');
            $this->form_validation->set_rules('confirm_password', 'Confirmar Senha', 'matches[password]');

            if ($this->form_validation->run()) {

                $data = elements(
                        array(
                    'first_name',
                    'email',
                    'password',
                    'active',
                    'username',
                        ), $this->input->post()
                );

                if (!$this->ion_auth->is_admin()) {
                    unset($data['active']);
                }


                //Limpar o array em caso de submissão de codigos maliciosos usando a lib security
                $data = $this->security->xss_clean($data);
                //verificar se o password foi passado, para evitar que os dados da bd sejam substituidos por dados em branco
                $password = $this->input->post('password');
                if (!$password) {
                    //caso o campo senha não seja passado, essa função evita que a senha seja enviada na bd
                    unset($data['password']);
                }


                if ($this->ion_auth->update($user_id, $data)) {

                    $perfil_usuario_db = $this->ion_auth->get_users_groups($user_id)->row();
                    $perfil_usuario_post = $this->input->post('perfil_usuario');


                    if ($this->ion_auth->is_admin()) {
                        //Se for diferente actualiza o grupo
                        if ($perfil_usuario_post != $perfil_usuario_db->id) {
                            $this->ion_auth->remove_from_group($perfil_usuario_db->id, $user_id);
                            $this->ion_auth->add_to_group($perfil_usuario_post, $user_id);
                        }
                    }
                    $this->session->set_flashdata('sucesso', 'Dados salvos com sucesso!');
                } else {
                    $this->session->set_flashdata('error', 'Erro ao salvar os dados!');
                }
                if ($this->ion_auth->is_admin()) {
                    redirect('usuarios');
                } else {

                    redirect('/');
                }
            } else {
                $data = array(
                    'titulo' => 'Editar Usuario',
                    'usuario' => $this->ion_auth->user($user_id)->row(),
                    'usuarios' => $this->ion_auth->users()->result(),
                    'perfil_usuario' => $this->ion_auth->get_users_groups($user_id)->row(),
                );

                $this->load->view('layout/header', $data);
                $this->load->view('usuarios/edit');
                $this->load->view('layout/footer');
            }
        }
    }

    public function email_check($email) {

        $user_id = $this->input->post('user_id');
        if ($this->core_model->get_by_id('users', array('email' => $email, 'id!=' => $user_id))) {
            $this->form_validation->set_message('email_check', 'Esse e-mail já existe');
            return FALSE;
        }
        return TRUE;
    }

    public function username_check($username) {

        $user_id = $this->input->post('user_id');
        if ($this->core_model->get_by_id('users', array('username' => $username, 'id!=' => $user_id))) {
            $this->form_validation->set_message('$username_check', 'Esse username já existe');
            return FALSE;
        }
        return TRUE;
    }

    public function del($user_id = NULL) {

        if (!$this->ion_auth->is_admin()) {
            redirect('/');
        }


        if (!$user_id || !$this->ion_auth->user($user_id)->row()) {
            $this->session->set_flashdata('error', 'Usuário não encontrado');
            redirect('usuarios');
        }
        if ($this->ion_auth->is_admin($user_id)) {
            $this->session->set_flashdata('error', 'O administrador não pode ser excluído');
            redirect('usuarios');
        }
        if ($this->ion_auth->delete_user($user_id)) {
            $this->session->set_flashdata('sucess', 'Usuário excluído com sucesso');
            redirect('usuarios');
        } else {
            $this->session->set_flashdata('sucess', 'Erro ao excluír o usuário');
            redirect('usuarios');
        }
    }

}
