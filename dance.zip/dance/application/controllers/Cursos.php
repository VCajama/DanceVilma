<?php

defined('BASEPATH') OR exit('Acção não permitida');

class Cursos extends CI_Controller {

    public function __construct() {
        parent::__construct();
         if(!$this->ion_auth->logged_in()){
            redirect('login');
        }
    }

    public function index() {

        $data = array(
            'titulo' => 'Listar cursos',
            'cursos' => $this->core_model->get_all('curso'),
        );
        $this->load->view('layout/header', $data);
        $this->load->view('cursos/index');
        $this->load->view('layout/footer');
    }

    public function edit($curso_id = NULL) {

        if (!$curso_id || !$this->core_model->get_by_id('curso', array('codCurso=' => $curso_id))) {
            $this->session->set_flashdata('error', 'Usuário não encontrado');
            exit('cursos');
        } else {
            $this->form_validation->set_rules('nome', '', 'trim|required');
            $this->form_validation->set_rules('curso_activo', '', 'required');
            if ($this->form_validation->run()) {
                $data = elements(
                        array(
                    'nome',
                    'curso_activo',
                        ), $this->input->post()
                );

                $this->core_model->update('curso', $data, array('codCurso=' => $curso_id));

                redirect('cursos');
            } else {
                $data = array(
                    'titulo' => 'Editar Curso',
                    'cursos' => $this->core_model->get_by_id('curso', array('codCurso=' => $curso_id)),
                );
                $this->load->view('layout/header', $data);
                $this->load->view('cursos/edit');
                $this->load->view('layout/footer');
            }
        }
    }

    public function del($curso_id = NULL) {
        if (!$curso_id || !$this->core_model->get_by_id('curso', array('codCurso=' => $curso_id))) {
            $this->session->set_flashdata('error', 'Curso não encontrado');
            redirect('cursos');
        }
        if (!$this->core_model->delete('curso', array('codCurso=' => $curso_id))) {
            $this->session->set_flashdata('sucess', 'Curso excluído com sucesso');
            redirect('cursos');
        } else {
            $this->session->set_flashdata('sucess', 'Erro ao excluír o curso');
            redirect('cursos');
        }
    }

    public function add() {
        $this->form_validation->set_rules('nome', '', 'trim|required|is_unique[curso.nome]');
        $this->form_validation->set_rules('curso_activo', '', 'required');
        if ($this->form_validation->run()) {
            $data = elements(
                    array(
                'nome',
                'curso_activo',
                    ), $this->input->post()
            );

            $this->core_model->insert('curso', $data);
            redirect('cursos');
        } else {

            $data = array(
                'titulo' => 'Cadastrar Cursos',
            );


            $this->load->view('layout/header', $data);
            $this->load->view('cursos/add');
            $this->load->view('layout/footer');
        }
    }

}
