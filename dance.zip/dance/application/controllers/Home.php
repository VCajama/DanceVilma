<?php

defined('BASEPATH') OR exit('Acção não permitida');

class Home extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (!$this->ion_auth->logged_in()) {
            redirect('login');
        }
    }

    public function index() {

        $data = array(
            'titulo' => 'Home',
            'cursos' => $this->core_model->get_all_cursos('curso'),
            'alunos' => $this->core_model->get_count_alunos(),
            'professores' => $this->core_model->get_count_professores(),
            'turmas' => $this->core_model->get_count_turmas(),
            'getCurso' => $this->core_model->get_curso(),
            'alunoTurma'=> $this->core_model->get_aluno_turma(),
            
        );


        $this->load->view('layout/header', $data);
        $this->load->view('home/index');
        $this->load->view('layout/footer');
    }

}
