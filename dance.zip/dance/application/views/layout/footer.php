<?php if (!$this->router->fetch_class() == 'login'): ?>

    <div class="footer">
        <p>&copy; 2016 Novus Admin Panel. All Rights Reserved | Design by <a href="https://w3layouts.com/" target="_blank">w3layouts</a></p>
    </div>

    <!--//footer-->
    </div>
    <!-- Classie -->
<?php endif; ?>
<script src="<?php echo base_url('public/js/classie.js') ?>"></script>
<script>
    var menuLeft = document.getElementById('cbp-spmenu-s1'),
            showLeftPush = document.getElementById('showLeftPush'),
            body = document.body;

    showLeftPush.onclick = function () {
        classie.toggle(this, 'active');
        classie.toggle(body, 'cbp-spmenu-push-toright');
        classie.toggle(menuLeft, 'cbp-spmenu-open');
        disableOther('showLeftPush');
    };

    function disableOther(button) {
        if (button !== 'showLeftPush') {
            classie.toggle(showLeftPush, 'disabled');
        }
    }
</script>
<!--scrolling js-->
<script src="<?php echo base_url('public/js/jquery.nicescroll.js') ?>"></script>
<script src="<?php echo base_url('public/js/scripts.js') ?>"></script>
<!--//scrolling js-->
<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url('public/js/bootstrap.js') ?>"></script>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Pronto para sair?</h4>
            </div>
            <div class="modal-body">
                <p>Clique em "Sair" para encerrar a sessão.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-sm " data-dismiss="modal">Não</button>
                <a class="btn btn-primary btn-sm" href="<?php echo base_url('login/logout');?>"> Sim</a>
            </div>
        </div>

    </div>
</div>
</body>
</html>