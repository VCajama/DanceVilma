<div id="page-wrapper">
    <div class="main-page login-page ">
        
        <div class="widget-shadow">
            <div class="login-top">
                <h4><a>Login </a> </h4>
            </div>
            <div class="login-body">
                <form class="user" name="form_autenticacao" method="POST" action="<?php echo base_url('login/autenticacao');?>">
                    <input type="text"  name="email" placeholder="Seu e-mail" required="">
                    <input type="password" name="password" class="lock" placeholder="Sua senha">
                    <input type="submit" name="Sign In" value="Sign In">
                    <div class="forgot-grid">
                        <label class="checkbox"><input type="checkbox" name="checkbox" checked=""><i></i>Remember me</label>
                        <div class="forgot">
                            <a href="#">forgot password?</a>
                        </div>
                        <div class="clearfix"> </div>
                    </div>
                </form>
            </div>
        </div>

    
</div>

<!--//footer-->
