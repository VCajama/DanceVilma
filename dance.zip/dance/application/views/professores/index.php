<div class="main-content">

    <?php $this->load->view('layout/sidebar') ?>

    <?php $this->load->view('layout/navbar') ?>

    <div id="page-wrapper">
        <div class="main-page">

            <div class="container">
                <a  href="<?php echo base_url('professores/add/'); ?>"><button type="button" class="btn btn-success pull-right">NOVO +</button></a>   
                <div class="row">
                    <div class="bs-example widget-shadow" data-example-id="hoverable-table"> 

                        <table class="table table-hover"> 
                            <thead> 
                                <tr> 
                                    <th>ID</th> 
                                    <th>Nome</th> 
                                    <th>Endereço</th>
                                    <th>Telefone</th>
                                    <th>Data de Nascimento</th>
                                    <th>Activo</th>
                                    <th>Acções</th>


                                </tr> 
                            </thead> 
                            <tbody> 
                                <?php foreach ($professores as $professor): ?>                         
                                    <?php if($professor->nome<>''): ?>
                                    <tr> 

                                        <td><?php echo $professor->codProfessor ?></td> 
                                        <td><?php echo $professor->nome ?></td> 
                                        <td><?php echo $professor->endereco ?></td> 
                                        <td><?php echo $professor->telefone ?></td> 
                                        <td><?php echo formata_data_banco_sem_hora($professor->dataNascimento) ?></td> 
                                        <td><?php echo ($professor->professor_activo == 1 ? '<span class="badge badge-success btn-sm">Sim</span>' : '<span class="badge badge-danger btn-sm">Não</span>') ?></td> 

                                        <th class="th-controls" >
                                            <a title="Editar" href="<?php echo base_url('professores/edit/' . $professor->codProfessor); ?>"  <button class="btn btn-success"> <i class="fa fa-pencil"></i> </button></a>
                                            <a title="Excluir" href="javascript(void)" data-toggle="modal" data-target="#professor-<?php echo $professor->codProfessor; ?>"> <button class="btn btn-danger"><i class="fa fa-trash-o"></i></button></a>
                                        </th>
                                    </tr>
                                <div id="professor-<?php echo $professor->codProfessor; ?>" class="modal fade" role="dialog">
                                    <div class="modal-dialog">
                                        <!-- Modal content-->
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                <h4 class="modal-title">Você está prestes a deletar um usuário?</h4>
                                            </div>
                                            <div class="modal-body">
                                                <p>Clique em <strong>Sim</strong> para excluir o registro</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary btn-sm " data-dismiss="modal">Não</button>
                                                <a class="btn-danger btn-sm" href="<?php echo base_url('professores/del/' . $professor->codProfessor); ?>">Sim</a>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php endforeach; ?>
                            </tbody> 

                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
