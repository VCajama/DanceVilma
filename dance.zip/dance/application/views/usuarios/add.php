<div class="main-content">

    <?php $this->load->view('layout/sidebar') ?>

    <?php $this->load->view('layout/navbar') ?>

    <div id="page-wrapper">
        <div class="main-page">
            <!-- <h3 class="title1">Gerir Alunos</h3> -->
            <div class="container">
                <div class="row center">
                    <div class="col-md-7">
                        <div class="form-grids row widget-shadow" data-example-id="basic-forms"> 
                            <div class="form-title">
                                <h4> Cadastrar Usuário</h4>
                            </div>
                            <div class="form-body">
                                <form method="POST" name="form_add"> 
                                    <div class="form-group"> 
                                        <label>Nome</label> 
                                        <input type="text" class="form-control" name="first_name" placeholder="Nome do usuario" value="<?php echo set_value('first_name'); ?>"> 
                                        <?php echo form_error('first_name', '<span class="help-block">', '</span>'); ?>
                                    </div>                                 
                                    <div class="form-group"> 
                                        <label>E-mail&nbsp;(Login)</label> 
                                        <input type="text" class="form-control" name="email" placeholder="Nome do usuario" value="<?php echo set_value('email'); ?>"> 
                                        <?php echo form_error('email', '<span class="help-block">', '</span>'); ?>

                                    </div> 
                                    <div class="form-group"> 
                                        <label>Usuário</label> 
                                        <input type="text" class="form-control" name="username" placeholder="Usuario" value="<?php echo set_value('username'); ?>"> 
                                        <?php echo form_error('username', '<span class="help-block">', '</span>'); ?>

                                    </div>


                                    <div class="form-group"> 
                                        <label class="control-label">Activo</label>
                                        <select name="active"  class="form-control1">
                                            <option value="0">Não</option>
                                            <option value="1">Sim</option>

                                        </select>
                                    </div> 
                                    <div class="form-group"> 
                                        <label class="control-label">Nível de acesso</label>
                                        <select name="perfil_usuario"  class="form-control1">
                                            <option value="2" >Usuário</option>
                                            <option value="1" >Administrador</option>

                                        </select>
                                    </div>
                                    <div class="form-group"> 
                                        <label>Senha</label> 
                                        <input type="password" class="form-control" name="password" placeholder="Senha do usuario" value=""> 
                                        <?php echo form_error('password', '<span class="help-block">', '</span>'); ?>
                                    </div> 
                                    <div class="form-group"> 
                                        <label>Confirmar Senha</label> 
                                        <input type="password" class="form-control" name="confirm_password" placeholder="Confirme a senha do usuario" value=""> 
                                        <?php echo form_error('confirm_password', '<span class="help-block">', '</span>'); ?>

                                    </div> 
                                    <input type="hidden" name="user_id" value="">

                                    <button type="submit" class="btn btn-default">Cadastrar</button>
                                </form> 
                            </div>
                        </div>
                    </div>   
                </div>

            </div>
        </div>
    </div>
</div>
