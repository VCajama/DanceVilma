<div class="main-content">

    <?php $this->load->view('layout/sidebar') ?>

    <?php $this->load->view('layout/navbar') ?>

    <div id="page-wrapper">
        <div class="main-page">

            <div class="container">
                <div class="row center">
                    <div class="col-md-7">
                        <div class="form-grids row widget-shadow" data-example-id="basic-forms"> 
                            <div class="form-title">

                                <h4>Cadastrar Turma</h4>

                            </div>
                            <div class="form-body">
                                <form method="POST" name="form_edit"> 

                                    <div class="form-group"> 
                                        <label>Nome</label> 
                                        <input type="text" class="form-control" name="nome" placeholder="Nome do turma" value="<?php echo set_value('nome'); ?>"> 
                                        <?php echo form_error('nome', '<span class="help-block">', '</span>'); ?>
                                    </div>
                                    <div class="form-group"> 
                                        <label  class="control-label">Dia de Semana</label>
                                        <select name="diaSemana"  class="form-control1">
                                            <option value="Segunda">Segunda</option>
                                            <option value="Terca">Terça</option>
                                            <option value="Quarta">Quarta</option>
                                            <option value="Quinta">Quinta</option>
                                            <option value="Sexta">Sexta</option>
                                            <option value="Sabado">Sabado</option>
                                            <option value="Domingo">Domingo</option>

                                        </select>
                                    </div>
                                    <div class="form-group"> 
                                        <label>Horario</label> 
                                        <input type="text" class="form-control" name="horario" placeholder="Horario das aulas" value="<?php echo set_value('horario'); ?>"> 
                                        <?php echo form_error('horario', '<span class="help-block">', '</span>'); ?>
                                    </div>

                                    <div class="form-group"> 
                                        <label  class="control-label">Professor Titular</label>
                                        <select name="codProfessor"  class="form-control1">
                                            <?php foreach ($professores as $prof) {

                                                if ($prof->nome <> '') {
                                                    ?>                         
                                                    <option value="<?php echo $prof->codProfessor; ?>">
                                                        <?php
                                                        echo $prof->nome;
                                                        ?>
                                                    </option>
                                                <?php }
                                            } ?>
                                        </select>

                                    </div>  
                                    <div class="form-group"> 
                                        <label  class="control-label">Professor Auxiliar</label>
                                        <select name="professorAuxiliar"  class="form-control1">
                                                <?php foreach ($professores as $prof) { ?>                         
                                                <option value="<?php echo $prof->codProfessor; ?>">
                                                    <?php
                                                    echo $prof->nome;
                                                    ?>
                                                </option>
                                            <?php } ?>

                                        </select>

                                    </div>  
                                    <div class="form-group"> 
                                        <label>Valor do Pagamento</label> 
                                        <input type="text" class="form-control" name="valorPropina" placeholder="Valor do paganto" value="<?php echo set_value('valorPropina'); ?>"> 
                                        <?php echo form_error('valorPropina', '<span class="help-block">', '</span>'); ?>
                                    </div>
                                    <div class="form-group"> 
                                        <label  class="control-label">Turma activa</label>
                                        <select name="turma_activo"  class="form-control1">
                                            <option value="0">Não</option>
                                            <option value="1">Sim</option>
                                        </select>
                                    </div>


                                    <button type="submit" class="btn btn-default">Salvar</button>
                                </form>
                            </div>
                        </div>
                    </div>   
                </div>

            </div>
        </div>
    </div>
</div>
