<div class="main-content">

    <?php $this->load->view('layout/sidebar') ?>

    <?php $this->load->view('layout/navbar') ?>

    <div id="page-wrapper">
        <div class="main-page">

            <div class="container">
                <a  href="<?php echo base_url('mensalidades/add/' . $mensalidade->codMensalidade); ?>"><button type="button" class="btn btn-success pull-right">NOVO +</button></a>   
                <div class="row">
                    <div class="bs-example widget-shadow" data-example-id="hoverable-table"> 

                        <table class="table table-hover"> 
                            <thead> 
                                <tr> 
                                    <th>ID</th> 
                                    <th>Nome do Aluno</th> 
                                    <th>Mês em referência</th>
                                    <th>Valor do pagamento</th>
                                    <th>Estado do Pagamento</th>
                                    <th>Acções</th>
                                </tr> 
                            </thead> 
                            <tbody> <?php $cont=1;?>
                                <?php foreach ($mensalidades as $mensalidade): ?>                         
                                
                                    <tr> 

                                        <td><?php echo $cont ?></td> 
                                        <td> <?php foreach ($alunos as $aluno) { ?> 

                                                <?php
                                                if ($aluno->codAluno == $mensalidade->codAluno) {
                                                    echo $aluno->nome;
                                                    break;
                                                }
                                                ?>
                                            <?php } ?>  </td>
                                        <td><?php echo $mensalidade->mes ?></td> 
                                        <td><?php echo $mensalidade->valorPropina . ' R$' ?></td> 
                                        <td><?php echo ($mensalidade->estado == 'PAGO' ? '<span class="badge badge-success btn-sm">Pago</span>' : 'PENDENTE') ?></td> 

                                        <th class="th-controls" >
                                            <a title="Editar" href="<?php echo base_url('mensalidades/listar/' . $mensalidade->codMensalidade); ?>"  <button class="btn btn-success"> <i class="fa fa-pencil"></i> </button></a>
                                            <a title="Excluir" href="javascript(void)" data-toggle="modal" data-target="#mensalidade-<?php echo $mensalidade->codMensalidade; ?>"> <button class="btn btn-danger"><i class="fa fa-trash-o"></i></button></a>
                                        </th>
                                    </tr>
                                <div id="mensalidade-<?php echo $mensalidade->codMensalidade; ?>" class="modal fade" role="dialog">
                                    <div class="modal-dialog">
                                        <!-- Modal content-->
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                <h4 class="modal-title">Você está prestes a deletar um usuário?</h4>
                                            </div>
                                            <div class="modal-body">
                                                <p>Clique em <strong>Sim</strong> para excluir o registro</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary btn-sm " data-dismiss="modal">Não</button>
                                                <a class="btn-danger btn-sm" href="<?php echo base_url('mensalidades/del/' . $mensalidade->codMensalidade); ?>">Sim</a>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                            <?php $cont++;
                            endforeach; ?>
                            </tbody> 

                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
