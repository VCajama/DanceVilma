<div class="main-content">

    <?php $this->load->view('layout/sidebar') ?>

    <?php $this->load->view('layout/navbar') ?>

    <div id="page-wrapper">
        <div class="main-page">
            <!-- <h3 class="title1">Gerir Alunos</h3> -->
            <div class="container">
                <div class="row center">
                    <div class="col-md-7">
                        <div class="form-grids row widget-shadow" data-example-id="basic-forms"> 

                            <div class="form-title">

                                <h4>Efectivar Pagamento de Mensalidade </h4>

                            </div>
                            <div class="form-body">
                                <form method="POST" name="form_edit"> 

                                    <div class="form-group"> 
                                        <label>Nome do aluno</label> 
                                        <input disabled=""   id="disabledinput" type="text" class="form-control" name="codAluno" placeholder="" value="<?php echo $mensalidade->codMensalidade;?>"> 
                                    </div>  
                                 
                                    <div class="form-group"> 
                                        <label>Mês de referência</label> 
                                        <input type="text" class="form-control" name="codMes" placeholder="" value=""> 
                                        
                                    </div> 

                                    <div class="form-group"> 
                                        <label>Valor a pagar</label> 
                                        <input disabled=""   id="disabledinput" type="text" class="form-control" name="valorPago" placeholder="" value=""> 
                                    </div>


                                    <button type="submit" class="btn btn-default">Salvar</button>
                                </form>
                            </div>
                        </div>
                    </div>   
                </div>

            </div>
        </div>
    </div>
</div>
