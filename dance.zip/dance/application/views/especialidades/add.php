f<div class="main-content">

    <?php $this->load->view('layout/sidebar') ?>

    <?php $this->load->view('layout/navbar') ?>

    <div id="page-wrapper">
        <div class="main-page">
       
            <div class="container">
                <div class="row center">
                    <div class="col-md-7">
                        <div class="form-grids row widget-shadow" data-example-id="basic-forms"> 
                            <div class="form-title">

                                <h4>Actualizar Especialidade </h4>

                            </div>
                            <div class="form-body">
                                <form method="POST" name="form_edit"> 

                                    <div class="form-group"> 
                                        <label>Nome</label> 
                                        <input type="text" class="form-control" name="nome" placeholder="Nome da especialidade" value="<?php echo set_value('nome'); ?>"> 
                                        <?php echo form_error('nome', '<span class="help-block">', '</span>'); ?>
                                    </div>  

                                    <div class="form-group"> 
                                        <label  class="control-label">Especialidade activa</label>
                                        <select name="especialidade_activo"  class="form-control1">
                                            <option value="0">Não</option>
                                            <option value="1">Sim</option>
                                        </select>
                                    </div>

                                    <button type="submit" class="btn btn-default">Salvar</button>
                                </form>
                            </div>
                        </div>
                    </div>   
                </div>

            </div>
        </div>
    </div>
</div>
