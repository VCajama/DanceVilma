<?php

defined('BASEPATH') OR exit('Acção não permitida');

class Core_model extends CI_Model {

    public function get_all($tabela = NULL, $condicao = NULL) {
        if ($tabela) {
            if (is_array($condicao)) {
                $this->db->where($condicao);
            }
            return $this->db->get($tabela)->result();
        } else {
            return FALSE;
        }
    }

    public function get_by_id($tabela = NULL, $condicao = NULL) {

        if ($tabela && is_array($condicao)) {
            $this->db->where($condicao);
            $this->db->limit(1);
            return $this->db->get($tabela)->row();
        } else {
            return FALSE;
        }
    }

    public function insert($tabela = NULL, $data = NULL, $get_last_id = NULL) {

        if ($tabela && is_array($data)) {
            $this->db->insert($tabela, $data);
            if ($get_last_id) {
                $this->session->set_userdata('last_id', $this->insert_id());
            }
            if ($this->affected > 0) {
                $this->session->set_flashdata('sucesso', 'Dados salvos com sucesso!');
            } else {

                $this->session->set_flashdata('error', 'Erro ao salvar dados!');
            }
        } else {
            return FALSE;
        }
    }

    public function update($tabela = NULL, $data = NULL, $condicao = NULL) {
        if ($tabela && is_array($data) && is_array($condicao)) {
            if ($this->db->update($tabela, $data, $condicao)) {
                $this->session->set_flashdata('sucesso', 'Dados salvos com sucesso!');
            } else {

                $this->session->set_flashdata('error', 'Erro ao actualizar dados!');
            }
        } else {
            return FALSE;
        }
    }

    public function delete($tabela = NULL, $condicao = NULL) {
        $this->db->db_debug = FALSE;
        if ($tabela && is_array($condicao)) {
            $status = $this->db->delete($tabela, $condicao);
            $error = $this->db->error();
            if (!$status) {
                foreach ($error as $code) {
                    //numero de erro de eliminar constrant 1451
                    if ($code == 1451) {
                        $this->session->set_flashdata('error', 'Esse registro não poderá ser excluído, pois está sendo utilizado em outra tabela!');
                    }
                }
            } else {
                $this->session->set_flashdata('sucesso', 'Registro excluído com sucesso!');
            }
            $this->db->db_debug = TRUE;
        } else {

            return FALSE;
        }
    }

    public function get_all_cursos($table = NULL) {
        if ($table) {
            $this->db->select('nome');
            $query = $this->db->get($table);
            return $query;
        }
    }

    public function get_count_alunos() {
        $query = $this->db->query("select count(*) as cont from aluno");
        return $query;
    }

    public function get_count_professores() {
        $query = $this->db->query("select count(*) as cont from professor");
        return $query;
    }

    public function get_count_turmas() {
        $query = $this->db->query("select count(*) as cont from turma");
        return $query;
    }

    public function get_curso() {
        $query = $this->db->query("select t.nome as turma,t.valorPropina as valor, count(c.codCurso) as qtdTurma
                                    from curso c, turma t where t.codCurso=c.codCurso group by t.codCurso");
        return $query;
    }

    public function get_aluno_turma() {
        $query = $this->db->query("SELECT t.nome as turma, count(at.codAluno) as qtdAluno FROM turma t,aluno_turma at,aluno a where at.codAluno=a.codAluno and t.codTurma=at.codTurma
                                            group by turma");
        return $query;
    }

}
